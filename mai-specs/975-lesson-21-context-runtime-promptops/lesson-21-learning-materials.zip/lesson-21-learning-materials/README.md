# 第 21 课 · 系统提示词与 Context Runtime

解压后打开[运行侧技术方案](TECH_DESIGN.html)或[PromptOps 管理侧技术方案](PROMPTOPS_TECH_DESIGN.html)。四类业务场景与发布验收见[产品需求](PRD.md)。[完整技术设计](TECH_DESIGN.md)开篇说明实际交付的资产粒度，后续章节展开运行时、管理端与跨入口实现。
